RPG SMP Crystal Resource Pack

Dieses Pack ist eine Vorlage fuer eigene Crystal-Texturen.

CustomModelData:
- Reset Crystal: 900001
- XP Crystal: 900002
- Attribute Crystal: 900003

Aktuell nutzen die Crystal-Modelle absichtlich die Vanilla-Texturen:
- Reset Crystal: minecraft:item/echo_shard
- XP Crystal: minecraft:item/experience_bottle
- Attribute Crystal: minecraft:item/amethyst_shard

So aenderst du die Texturen:
1. Lege eigene PNG-Dateien in assets/rpgsmp/textures/item/.
   Beispiel:
   - reset_crystal.png
   - xp_crystal.png
   - attribute_crystal.png
2. Oeffne die passenden Dateien in assets/rpgsmp/models/item/.
3. Aendere dort layer0 z.B. von minecraft:item/echo_shard zu rpgsmp:item/reset_crystal.
4. Zippe den Inhalt dieses resource-pack Ordners, nicht den Ordner selbst.

Wichtig:
pack.mcmeta muss direkt im ZIP liegen.
